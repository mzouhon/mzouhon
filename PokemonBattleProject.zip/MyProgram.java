import java.util.Scanner; 
import java.util.Random;
public class MyProgram
{
    public static void main(String[] args){
    
      
     Scanner x= new Scanner (System.in);
       
       
     System.out.println("What is the name of Player 1's pokemon?");
     String name1= x.nextLine();
     System.out.println("What is "+ name1 + "'s type?");
     String type1=x.nextLine();
     System.out.println("What is " + name1 +  "'s base HP?");
     int baseHP1= x.nextInt();
     System.out.println("What is " + name1 + "'s level?");
     int level1= x.nextInt();
     System.out.println("What is " + name1 + "'s base Attack stat?");
     int baseAS1=x.nextInt();
     System.out.println("What is " + name1 + "'s base Defense stat?");
     int defense1=x.nextInt();
     /***with the help of a paper tutor, realized that using nextInt doesn't 
     retrieve the enter key, only the integer, so in order to avoid 
     having the next user input be automatically read as the enter key, 
     "you have to "clear" the line
     ***/
     x.nextLine();
     System.out.println("What is " + name1 + "'s attack type?");
     String attackType1= x.nextLine();
       
     System.out.println("What is the name of Player 2's pokemon?");
     String name2= x.nextLine();
     System.out.println("What is "+ name2 + "'s type?");
     String type2=x.nextLine();
     System.out.println("What is " + name2 +  "'s base HP?");
     int baseHP2= x.nextInt();
     System.out.println("What is " + name2 + "'s level?");
     int level2= x.nextInt();
     System.out.println("What is " + name2 + "'s base Attack stat?");
     int baseAS2=x.nextInt();
     System.out.println("What is " + name2 + "'s base Defense stat?");
     int defense2=x.nextInt();
     //"clearing" line of enter key
     x.nextLine();
     System.out.println("What is " + name2 +  "'s attack type?");
     String attackType2=x.nextLine();
       
     //calling method that prints the pokemon card
     printPokemonCard(name1,type1,level1, baseHP1, baseAS1, defense1);
     printPokemonCard(name2,type2,level2, baseHP2, baseAS2, defense2);
       
     //calling method that calculates the leveled HP and attack stat
     int leveledHP1= calculateLHP(name1,baseHP1,level1);
     int leveledAS1=calculateLAS(baseAS1, level1);
     int leveledHP2= calculateLHP(name2,baseHP2,level2);
     int leveledAS2=calculateLAS(baseAS2, level2);
   
     System.out.println("Let's battle!"); 
     System.out.println(name1 + "'s Starting HP: " + leveledHP1);
     System.out.println(name2 + "'s Starting HP: " + leveledHP2);
       
     int newHP1= leveledHP1;
     int newHP2=leveledHP2;
     int count=0;
       
     /*while loop that displays battle information and ensures battle ends when
     one HP reaches 0
     */
     while ( newHP1>0 && newHP2>0){
       count++;
       System.out.println("Battle "+ count);
       
       newHP1= (int)(newHP1-calculateAttackDamage(randomMultiplier(),level2, leveledAS2, defense1, type1, attackType2));
       if (newHP1<1){
           newHP1=0;
       }
       System.out.println(name1 + "'s Current HP"+ ": "+ newHP1);
       if (newHP1<=0){
           break; 
       }
       
       newHP2= (int)(newHP2- calculateAttackDamage(randomMultiplier(),level1, leveledAS1, defense2, type2, attackType1));
       if (newHP2<1){
           newHP2=0;
       }
       System.out.println(name2 + "'s Current HP"+ ": " +newHP2);
       if (newHP2<=0){
         break;
       }
     } 
      
      
     if(newHP1 > 0){
       System.out.println(name1 + " has won the battle!");
     }else{
       System.out.println(name2 + " has won the battle!");
     }
    }
 
/*This method calculates the leveled HP at the beginning of a battle
using name, base HP, and level. The use of the if statement ensures that
the pokemon Shedinja always has a HP of 1. The for statment ensures that 
every level 1 pokemon has an HP of 11 and higher levels are calculated 
accordingly and returned.
  
*/
public static int calculateLHP(String name,int baseHP,int level){
     double leveledHP=11;
     String specialCase= "Shedinja";
       
     if (name.equals(specialCase)){
           leveledHP=1;
     }else{
            for (int i=1; i<level; i++) {
              leveledHP=leveledHP+(1/50.0)*baseHP+1; 
            }
     }
       return (int)leveledHP;
}
    
/*
This method calculates the leveled attack stat base on the base attack
stat and level. It ensures that any level 1 pokemon has an attack stat
of 5 and every other level pokemon is calculated accordingly and returned.
*/
public static int calculateLAS(int baseAS,int level){
     double leveledAS=5;
     for(int i=1; i<level;i++){
         leveledAS=leveledAS+(1/50.0)*baseAS+1;
     }
     return (int)leveledAS;
}
       
/*This method prints the pokemon card and returns nothing.
*/
public static void printPokemonCard(String name, String type, int level, int baseHP, int baseAS, int defense ){
       System.out.println("+========================+");
       System.out.println("| POKEMON: "+ name);
       System.out.println("|------------------------");
       System.out.println("| TYPE: "+ type);
       System.out.println("| LEVEL: "+ level);
       System.out.println("| HP: "+ baseHP);
       System.out.println("| ATTACK: "+ baseAS);
       System.out.println("| DEFENSE: "+ defense);
       System.out.println("+========================+");
    
     }
 /* This method calculates the random number used in calculating attack
damage*/
public static double randomMultiplier(){
        Random rand = new Random(); 

        double double_random = rand.nextDouble()*0.15 + 0.85;
        
        return double_random;
}
/* This method calculates attack damage based on all the stats needed and 
returns the damage. Depending on whther the attacker's attack matches the defendant's type
the damage may be multiplied by 1.5 before being returned*/
public static int calculateAttackDamage(double modifier, int level, int leveledAS, int defense, String oppType, String attackType){
     double damage= modifier*((2*level+10)/250+(leveledAS/defense)+2);
     if (attackType.equals(oppType)){
            damage= damage*1.5;
        }
     return (int)damage;
    }
}
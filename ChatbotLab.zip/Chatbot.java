/**
 * This code adapted from
 * @author Laurie White
 * 
 * -------
 * SUMMARIZE SOURCES YOU CONSULTED HERE
 * You are expected to attempt this work on your own
 * And to completely understand all code you submit
 * If you consulted any people, websites, etc, you must list the source here.
 * You must also add in-line comments that explain what code is yours
 * 
 */
public class Chatbot
{
    // instance variables for storing name and favorite color
    String name;
    String favoriteColor;
    String pet;
    String petName;
    String instrument;
    
    //instance variables for list of what is known about the user
    String qname;
    String qfavoriteColor;
    String qpet;
    String qpetName;
    String qinstrument;
    
    
	public String greeting()
	{
	//modified
		return "Hey, what's going on?";
	}
	
	
	public String getResponse(String statement)
	{
		String response = "";
		
	if(statement.indexOf("My name is")>=0)
	{
	    findName(statement);
	    response= "Hello " + name + ".";
	}else if (statement.indexOf("My favorite color is")>=0)
	{
	    findColor(statement);
	    response= "I like " + favoriteColor + " too!";
	    
	}else if(statement.indexOf("What is my name")>=0)
	{
	 //verified this with stack overflow forum but came up with it on
	 //my own because when nothing was set for the name variable,
	 //null was displayed
	 if (name != null){
	   response= "Your name is " + name + ".";
	 } else{
	     response= "You never told me your name. What is your name?";
	 }
	
	}else if (statement.indexOf("What is my favorite color")>=0)
	{
	if (favoriteColor !=null){
	    response= "Your favorite color is " + favoriteColor + ".";
	}else{
	    response="You never told me your favorite color. What is your favorite color?";
	}
	
	}else if(statement.indexOf("My pet is a ")>=0)
	{
	    findPet(statement);
	    response= "I love " + pet + "s!";
	
	
	}else if (statement.indexOf("My pet's name is ")>=0)
	{
	    findPetName(statement);
	    response= "I bet " + petName + " is the best pet!";
	
	    
	}else if (statement.indexOf("What's my pet's name")>=0)
	{
	  if (pet != null && petName != null) {
	      response= "Your " + pet + "'s name is " + petName + ".";
	  } else if (pet == null && petName !=null){
	      response= "Your pet's name is "+ petName + ".";
	  }else{
	      response= "You never told me your pet's name. What is your pet's name?";
	  }
	//added field of info taken from user
	}else if (statement.indexOf("I play the")>=0){
	    findInstrument(statement);
	    response= "The "+ instrument + "'s my favorite instrument!";
	}else if(statement.indexOf("What instrument do I play?")>=0){
	    if (instrument != null){
	        response= "You play the " + instrument + ".";
	    }else{
	        response= "You never told me what instrument you play. What instrument do you play?";
	    }
	}
	//use of qvariable variables allows me to list what variables are unknown without changing the actual value of the instance variable
	else if (statement.indexOf("What do you know about me")>=0)
	{
	  if (name != null)  {
	    qname= name;  
	} else{
	    qname= "unknown";
	}
	
	if (favoriteColor != null){
	    qfavoriteColor= favoriteColor;
	}else{
	    qfavoriteColor="unknown";
	}
	if (pet != null){
	    qpet= "a " + pet;
	}else{
	    qpet="an unknown pet";
	}
	if(petName != null){
	    qpetName= petName;
	}else{
	    qpetName= "unknown";
	}if(instrument != null){
	    qinstrument= "the " + instrument;
	}else{
	    qinstrument="unknown";
	}
	
	response = "Your name is " + qname + "." + "\nYour favorite color is " + qfavoriteColor + "." + "\nYou have " + qpet + "." + "\nYour pet's name is "+ qpetName + "." + "\nThe instrument you play is "+ qinstrument + ".";
	
	}else if (
	    statement.indexOf("dog") >=0 ||
	    statement.indexOf("cat") >= 0 ||
	    statement.indexOf("fish") >=0 ||
	    statement.indexOf("turtle") >=0
	    )
	    {
	   /**while I did use Paper to attempt to figure out
	    * how to incorporate the pet Statement, I ended up
	    * figuring it out on my own. I didn't realize that
	    * the pet statment was just another method,
	    * similar to the random responses method.
	    **/
	     response= petStatement();
	    
	        
	    }else if (
	   
	    statement.indexOf("mr.")>=0 ||
	    statement.indexOf("mrs.")>=0 ||
	    statement.indexOf("mx.")>=0 
	    )
	   {
	   /**modeled after petStatement
	    **/
	     response=teacherStatement(statement);  
	    
	   //modeled after teacherStatement 
	       
	   }else if(
	        statement.indexOf("piano") >=0 ||
	        statement.indexOf("guitar")>=0 ||
	        statement.indexOf("violin")>=0 ||
	        statement.indexOf("drums")>=0 ||
	        statement.indexOf("cello")>=0
	        )
	       {
	       response=musicStatement(statement);
	   //modeled after teacher statement
	   }else if(
	       statement.indexOf("track") >=0 ||
	       statement.indexOf("soccer")>=0 ||
	       statement.indexOf("basketball")>=0 ||
	       statement.indexOf("baseball")>=0 ||
	       statement.indexOf("football")>=0 
	       )
	   {
	      response=sportsStatement(statement);
	   //modeled after teacher statement
	    }else if(
	        statement.indexOf("french") >=0 ||
	        statement.indexOf("spanish")>=0 ||
	        statement.indexOf("chinese")>=0
	        )
	    
	    {
	        response= languageStatement(statement);
	    //modeled after teacher statement
	    }else if(
	        statement.indexOf("pasta")>=0 ||
	        statement.indexOf("cereal")>=0||
	        statement.indexOf("chicken")>=0
	        )
	    {
	        response= foodStatement(statement);
	    
	    }else if (
		    statement.indexOf("no") >=0 
		)
		{
		    //modified response
		    response = "Lighten up!";
		} else if (
		    statement.indexOf("mother") >= 0 ||
		    statement.indexOf("brother") >= 0 ||
		    statement.indexOf("sister") >= 0 ||
		    statement.indexOf("father") >= 0
		)
	    {
	        //modified response
	        response = "Tell me more about this family of yours!";
	    } else if (
	        statement.indexOf("weather") >= 0 ||
		    statement.indexOf("sun") >= 0 ||
		    statement.indexOf("rain") >= 0
        )
        {
            //modified response
            response = "The weather here is really nice. I mean as nice as virtual weather can be!";
        } else if(
        /**used stack overflow forum to figure out 
         * how to use trim method.
         * Also eavesdropped on Mr. Jones's and Nadia's
         * conversation on how to combine the trim and length
         * methods
        **/
         statement.trim().length()<=1 
            )
        {
            response= shortStatement(statement);
            
        }else {
            response = randomResponse();
        }
		return response;
	}

	 
	 /** pet Statement method is called whenever an animal keyword
	  * is recognized (in my case only dog,cat,fish,turtle)
	  **/
	public String petStatement()
	{
	    String response= "Tell me more about your pets!";
	    return response;
	}
	
	/**teacher Statement is called whenever a mrs., mr. or mx i
	 * detected. An if statement is used to assure the proper
	 * use of pronouns.
	*/
	public String teacherStatement(String statement)
	{
	   String response="";
	   if (statement.indexOf("mr.")>=0){
	    response= "What's he like?";
	   }else if (statement.indexOf("mrs.")>=0){
	       response="What's she like?";
	   }else{
	   response= "What are they like?";
	   }
	   return response;
	}
	
	public String shortStatement(String statement)
	{
	    String response="";
	    
	    /**use and if statement to give different responses
	     * depending on if nothing was typed or if a single
	     * letter was typed
	    **/
	    if(statement.trim().length()==0){
	        response= "Talk to me...please.";
	    }else{
	    response= "Imma need more than that, buddy.";
	}
	    return response;
	}
	
	public String musicStatement(String statement)
	{
	    String response="";
	    //use of if statement to give appropriate response
	    //based on instrument
	   
	    
	    if(statement.indexOf("piano")>=0){
	        response= "What's your favorite song to play on piano?";
	    }else if(statement.indexOf("guitar")>=0){
	        response="What kind of songs do you play on guitar?";
	    }else if(statement.indexOf("violin")>=0){
	        response="How long have you been playing violin?";
	    }else if(statement.indexOf("drums")>=0){
	        response= "What led you to start playing the drums?";
	    }else{
	        response= "What's the hardest thing about playing the cello?";
	    }
	    return response;
	}
	
	public String sportsStatement(String statement)
	{
	    String response="";
	    //if statement used to give appropriate response based on sport
	    if(statement.indexOf("track")>=0){
	        response= "What's your favorite event?";
	    }else {
	        response= "Who's your favorite team and player?";
	    }
	    return response;
	}
	
	public String languageStatement(String statement)
	{
	    String response="";
	    //if statement used to give correct response based on language
	    if(statement.indexOf("french")>=0){
	        response="Bonjour, je ma'appelle Chatbot! What can you say in French?";
	    }else if(statement.indexOf("spanish")>=0){
	        response= "Hola, mi nombre es Chatbot! What can you say in Spanish?";
	    }else{
	        response= "Nî hâo, wô de míngzì shì Chatbot! What can you say in Chinese?";
	    }
	    return response;
	}
	
	public String foodStatement(String statement)
	{
	    String response="";
	    //if statement used to give correct response based on food
	    if(statement.indexOf("pasta")>=0){
	        response="What's your favorite pasta dish?";
	    }else if(statement.indexOf("cereal")>=0){
	        response="What's your favorite breakfast cereal?";
	    }else{
	        response="What's your favorite kind of chicken?";
	    }
	    return response;
	}
	
	private String randomResponse()
	{
		int NUMBER_OF_RESPONSES = 12;
		double responseIndex = Math.random();
		int whichResponse = (int)(responseIndex * NUMBER_OF_RESPONSES);
		String response = "";
		//modified
		if (whichResponse == 0)
		{
			response = "Very, very cool!";
		}
		else if (whichResponse == 1)
		{
			response = "You don't say?";
		}
		else if (whichResponse == 2)
		{
			response = "Um...interesting.";
		}
		else if (whichResponse == 3)
		{
			response = "Can we talk about something else?";
		}
		else if (whichResponse == 4)
		{
			response = "Booooring. Oh sorry did I say that out loud?";
		}
		else if (whichResponse == 5)
		{
			response = "You really like to talk, don't you?";
		}else if(whichResponse==6)
		
		{
		    //these last six are mine
		  response="That's awesome but can I ask if you play any instruments?";  
		}else if (whichResponse==7)
		{
		  response= "That's cool but I was wondering if you played any sports." ; 
		}else if (whichResponse==8)
		{
		    response= "Intriguing but may I ask if you speak any languages other than English?";
		}else if(whichResponse==9)
		{
		    response= "Interesting, do you have any favorite foods?";
		}else if(whichResponse==10)
		{
		  response= "I'm not sure about that but could you tell me about your family?";  
		}else if(whichResponse==11)
		{
		    response= "Cool! Do you have any pets?";
		}
		return response;
	}
	//used the GeeksforGeeks website to learn how substring works
	public String findName(String statement){
	        name=statement.substring(11);
	        // used System.out.println(name) to ensure it was picking up
	        //the correct substring
	    return name;
	}
	//copied format for findName for the rest of the find Methods
	public String findColor(String statement){
	      favoriteColor= statement.substring(21);
	      return favoriteColor;
	  
	}
	public String findPet(String statement){
	    pet=statement.substring(12);
	    return pet;
	}
	public String findPetName(String statement){
	    petName= statement.substring(17);
	    return petName;
	}
	
	public String findInstrument(String statement){
	    instrument= statement.substring(11);
	    return instrument;
	}
}